
const express = require('express');
const router = express.Router();
const Order = require('../models/Order');

router.post('/create', async (req, res) => {
  const { userId, product } = req.body;
  const newOrder = new Order({ userId, product });
  await newOrder.save();
  res.json({ message: 'Order created', order: newOrder });
});

router.get('/status/:id', async (req, res) => {
  const order = await Order.findById(req.params.id);
  if (!order) return res.status(404).json({ message: 'Order not found' });
  res.json(order);
});

module.exports = router;
