
const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const User = require('../models/User');

router.get('/users', async (req, res) => {
  const users = await User.find();
  res.json(users);
});

router.get('/orders', async (req, res) => {
  const orders = await Order.find();
  res.json(orders);
});

module.exports = router;
